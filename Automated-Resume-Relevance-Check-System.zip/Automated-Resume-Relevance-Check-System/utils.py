import os
from resume_parser import parse_resume

def load_resumes_from_folder(folder_path):
    resumes = []
    file_names = []
    for file in os.listdir(folder_path):
        if file.endswith('.pdf') or file.endswith('.docx'):
            text = parse_resume(os.path.join(folder_path, file))
            resumes.append(text)
            file_names.append(file)
    return resumes, file_names
