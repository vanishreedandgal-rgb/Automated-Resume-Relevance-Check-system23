import streamlit as st
from utils import load_resumes_from_folder
from job_matching import rank_resumes, train_vectorizer

st.title("Automated Resume Relevance Check System")

resumes_folder = st.text_input("Enter resumes folder path", "data/sample_resumes")
resumes, filenames = load_resumes_from_folder(resumes_folder)

job_file = st.file_uploader("Upload Job Description (.txt)", type=['txt'])

if job_file:
    job_text = job_file.read().decode("utf-8")
    train_vectorizer(resumes + [job_text])
    scores = rank_resumes(resumes, job_text)
    ranked = sorted(zip(filenames, scores), key=lambda x: x[1], reverse=True)
    st.subheader("Ranked Resumes")
    for fname, score in ranked:
        st.write(f"{fname} - Relevance Score: {score:.2f}")
