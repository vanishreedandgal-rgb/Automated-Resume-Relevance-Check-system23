import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def train_vectorizer(sample_texts):
    vectorizer = TfidfVectorizer(stop_words='english')
    vectorizer.fit(sample_texts)
    with open('models/skill_vectorizer.pkl', 'wb') as f:
        pickle.dump(vectorizer, f)
    return vectorizer

def load_vectorizer():
    with open('models/skill_vectorizer.pkl', 'rb') as f:
        return pickle.load(f)

def compute_similarity(resume_text, job_text, vectorizer):
    vectors = vectorizer.transform([resume_text, job_text])
    similarity = cosine_similarity(vectors[0], vectors[1])[0][0]
    return similarity

def rank_resumes(resumes_texts, job_text):
    vectorizer = load_vectorizer()
    scores = []
    for r in resumes_texts:
        score = compute_similarity(r, job_text, vectorizer)
        scores.append(score)
    return scores
