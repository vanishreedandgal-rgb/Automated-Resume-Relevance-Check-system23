# Automated Resume Relevance Check System

This project is an AI-powered system to automatically evaluate resumes against job descriptions and rank candidates based on relevance.

## Features
- Parse resumes in PDF and DOCX formats.
- Extract skills and experience using NLP.
- Match resumes to job descriptions.
- Calculate a relevance score for each candidate.
- Streamlit web app for easy usage.

## Setup

1. Clone the repository:
```bash
git clone <YOUR_GITHUB_REPO_URL>
cd Automated-Resume-Relevance-Check-System
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the Streamlit web app:
```bash
streamlit run app.py
```

## Usage
- Upload resumes and a job description through the web app.
- Get a ranked list of candidates based on relevance.

## Author
Vanishree Dandgal
